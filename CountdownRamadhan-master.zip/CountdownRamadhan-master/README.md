# CountdownRamadhan
Countdown Ramadhan dengan Android

# Tutorial Build with Video
https://youtu.be/7ITN6QTbpFo

# Tutorial Build with Android Studio
https://rivaldi48.blogspot.com/2020/04/Tutorial-Membuat-Countdown-Bulan-Ramadhan-dengan-Android-Studio.html

